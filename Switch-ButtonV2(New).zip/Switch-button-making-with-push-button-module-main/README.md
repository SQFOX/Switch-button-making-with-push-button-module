# Switch-button-making-with-push-button-module
Codes for converting push button to switch button (there are c++ codes for the moment).

You just need to adapt the codes according to you.
It is written only in C++ for now.

The part where I explain the codes is in the part that is written as a comment line of the file I gave the codes.
